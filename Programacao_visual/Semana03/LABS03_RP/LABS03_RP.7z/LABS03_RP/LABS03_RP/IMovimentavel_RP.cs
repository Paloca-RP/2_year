﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABS03_RP
{
    interface IMovimentavel_RP
    {
        void Mover_RP(int dx, int dy);
    }
}

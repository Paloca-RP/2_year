﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LABS03_RP
{
    interface IRedimensionável_RP
    {
        void Redimensionar_RP(int valor);
    }
}

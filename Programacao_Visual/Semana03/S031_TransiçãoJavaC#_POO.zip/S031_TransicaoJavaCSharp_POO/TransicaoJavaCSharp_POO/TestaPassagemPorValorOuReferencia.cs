﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TP02_POO
{
    class TestaPassagemPorValorOuReferencia
    {
        public int i = 0;

        public int getI() { return i; }
        public void setI(int i) { this.i = i; }

    }
}

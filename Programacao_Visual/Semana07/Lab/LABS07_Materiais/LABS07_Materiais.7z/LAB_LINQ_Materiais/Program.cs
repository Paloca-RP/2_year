﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace LAB06
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Product> products = CriarProdutos();

            Console.WriteLine("Lista de Produtos: \n");
            foreach (Product product in products)
            {
                Console.WriteLine("{0:00} - {1}", product.ProductId, product.ProductName);
            }
            Console.ReadKey();
            Console.Clear();

            //Testes LinQ

            var todos = from i in products select i;

            List<Product> snapshotDosProdutos = todos.ToList();

            foreach (Product product in snapshotDosProdutos)
            {
                Console.WriteLine(product);
            }
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\tNivel 1 xxxx");
            //tds os alunos
            Console.WriteLine("\n******* Todos os Productos *******");
            var todosProdutos = from i in products
                                select i.ProductName;
            foreach (var i in todosProdutos)
                Console.WriteLine(i.ToString());
            //tds os productos sem stock
            Console.WriteLine("\n******* Productos sem stock *******");
            var tdsSemStock = from i in products
                              where i.UnitsInStock == 0
                              select i.ProductName;
            foreach (var i in tdsSemStock)
                Console.WriteLine(i.ToString());
            //tds os nomes ordem alfabética
            Console.WriteLine("\n******* Productos por Ordem alfabética *******");
            var tdsNomes = from i in products
                           orderby i.ProductName
                           select i.ProductName;
            foreach (var i in tdsNomes)
                Console.WriteLine(i.ToString());
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\t Nivel 2 xxxx");
            //lista de bebidas que custam menos de 25€
            //ordenadas pelo preço.
            var listBebidas = from i in products
                              where i.Category == "Beverages"
                              orderby i.UnitPrice < 25
                              select i.ProductName;
            foreach (var i in listBebidas)
                Console.WriteLine(i.ToString());
            Console.ReadKey();
            Console.Clear();
            products.Add(new Product()
            {
                ProductId = 78,
                ProductName = "Sagres",
                Category = "Beverages",
                UnitPrice = 12.2000M,
                UnitsInStock = 25
            });
            products.Add(new Product()
            {
                ProductId = 79,
                ProductName = "Super Bock",
                Category = "Beverages",
                UnitPrice = 10.1000M,
                UnitsInStock = 15
            });
            foreach (var i in listBebidas)
                Console.WriteLine(i.ToString());
            Console.ReadKey();

            var numAuto = (from i in products
                           select i.ProductId).Max() + 1;
            products.Add(new Product
            {
                ProductId = numAuto,
                ProductName = "Carlsberg",
                Category = "Beverages",
                UnitPrice = 18.1M,
                UnitsInStock = 12
            });
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\tNivel 3 xxxx");
            var barato = (from i in products
                          select i.UnitPrice).Min();
            Console.WriteLine("Mais Barato: " + barato);

            var caro = (from i in products
                        select i.UnitPrice).Max();
            Console.WriteLine("Mais Caro: " + caro);

            var media = (from i in products
                         select i.UnitPrice).Average();
            Console.WriteLine("Média dos Preços" + media);
            Console.ReadKey();
            Console.WriteLine("\n listagem de prodctos e seus preços totais\n");
            decimal totalStock = 0;
            var totalstocks = from i in products
                              select new
                              {
                                  Nome = i.ProductName,
                                  Valor_Total = (i.UnitPrice * i.UnitsInStock)
                              };
            foreach (var i in totalstocks)
            {
                Console.WriteLine("Nome: " + i.Nome + " \nValor Total: " + i.Valor_Total);
                totalStock += i.Valor_Total;
            }
            Console.WriteLine("\nValor total dos produtos em stock: " + totalStock);
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\t Nivel 4 xxxx");

            Console.WriteLine("Preços de Forma Ascendente\n");
            var listaAscendente = products.OrderBy(i => i.UnitPrice).Select(i => i);
            foreach (var i in listaAscendente)
                Console.WriteLine(i.ToString());

            Console.WriteLine("\nCategorias sem repetição das mesma\n");
            var semRep = products.Select(i => i.Category).Distinct();
            foreach (var i in semRep)
                Console.WriteLine(i.ToString());

            var custoHigh = products.Where(i => i.UnitPrice > 200).Select(i => i).Any();
            if (custoHigh == true)
                Console.WriteLine("\nExistem Productos com custo maior que 200\n");
            else
                Console.WriteLine("\nNão Existem Productos com custo maior que 200\n");

            var MediaStocks = products.Select(i => i.UnitsInStock).Average();
            Console.WriteLine("Média de Unidades: " + MediaStocks);
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\t Nivel 5 xxxx");

            Console.WriteLine("\nOs primeiros 3 produtos que custam mais de 50 (operador Take)");
            var tresPrimeiros = (from i in products
                                 where i.UnitPrice > 50
                                 select i).Take(3);
            foreach (var i in tresPrimeiros)
                Console.WriteLine(i.ToString());

            Console.WriteLine("\nO quarto e o quinto produto começado pela letra C (operadores Take e Skip)");
            var produtosC = (from i in products
                             where i.ProductName.StartsWith("C")
                             select i).Take(5).Skip(3);
            foreach (var i in produtosC)
                Console.WriteLine(i.ToString());

            Console.WriteLine("\nA lista de produtos ordenada pela categoria e depois pelo nome do produto (operadores OrderBy e ThenBy)");
            var CategoriaNome = products.OrderBy(i => i.Category)
                               .ThenBy(i => i.ProductName)
                               .Select(i => i);
            foreach (var i in CategoriaNome)
                Console.WriteLine(i.ToString());

            Console.WriteLine("\nMostre cada categoria seguida da lista de produtos incluídos na mesma (GroupBy)");
            var ProdutosCategoria = products.GroupBy(i => i.Category)
                                    .Select(i => i);
            foreach (var o in ProdutosCategoria)
            {
                Console.WriteLine("Categoria: " + o.Key);
                foreach (var i in o)
                    Console.WriteLine(i.ToString());
            }
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\t Nivel 6 xxxx");
            
            Produtos listaProdutos = new Produtos();
            foreach (var ex62 in products)
                listaProdutos.Add(ex62);

            foreach (var GetListaProdutos in listaProdutos.GetListaProdutos())
                Console.WriteLine(GetListaProdutos.ToString());


            foreach (var GetProdutosSemStock in listaProdutos.GetProdutosSemStock())
                Console.WriteLine(GetProdutosSemStock.ToString());


            foreach (var GetListaProdutosOrdemAlfabetica in listaProdutos.GetListaProdutosOrdemAlfabetica())
                Console.WriteLine(GetListaProdutosOrdemAlfabetica.ToString());


            foreach (var GetListaBebidasMenos25Euros in listaProdutos.GetListaBebidasMenos25Euros())
                Console.WriteLine(GetListaBebidasMenos25Euros.ToString());


            Console.WriteLine("Produto mais barato: " + listaProdutos.GetProdutoMaisBarato().ToString());
            Console.WriteLine("Produto mais caro: " + listaProdutos.GetProdutoMaisCaro().ToString());
            Console.WriteLine("Média de preços: " + listaProdutos.GetMediaPreco());


            foreach (var GetDinheiroStockPorProduto in listaProdutos.GetDinheiroStockPorProduto())
                Console.WriteLine(GetDinheiroStockPorProduto.ToString());


            foreach (var GetListaProdutosOrdenadaPreco in listaProdutos.GetListaProdutosOrdenadaPreco())
                Console.WriteLine(GetListaProdutosOrdenadaPreco.ToString());


            foreach (var GetCategoriaProdutos in listaProdutos.GetCategoriaProdutos())
                Console.WriteLine(GetCategoriaProdutos.ToString());


            Console.WriteLine("\nProdutos com um custo maior que 200: " + listaProdutos.ProdutosMiasCarosQue200());

            Console.WriteLine("\nNúmero médio de unidades em stock: " + listaProdutos.GetMediaUnidadesEmStock());

            foreach (var GetPrimeiros3ProdutosCustamMais50 in listaProdutos.GetPrimeiros3ProdutosCustamMais50())
                Console.WriteLine(GetPrimeiros3ProdutosCustamMais50.ToString());

            foreach (var Get4e5ComecamPorC in listaProdutos.Get4e5ComecamPorC())
                Console.WriteLine(Get4e5ComecamPorC.ToString());

            foreach (var GetProdutosOrdenadosCategoriaENome in listaProdutos.GetProdutosOrdenadosCategoriaENome())
                Console.WriteLine(GetProdutosOrdenadosCategoriaENome.ToString());
            
            foreach (var GetProdutosPorCategoria in listaProdutos.GetProdutosPorCategoria())
            {
                Console.WriteLine("Categoria: " + GetProdutosPorCategoria.Key);
                foreach (var i in GetProdutosPorCategoria)
                    Console.WriteLine(i.ToString());
            }
            Console.ReadKey();
            Console.Clear();

            Console.WriteLine("\t Nivel 7 xxxx");

            Console.WriteLine("\nRemover do stock uma quantidade de um produto");
            Stock stock = new Stock();
            stock.Add(listaProdutos[39], 1);
            Console.WriteLine(stock.ToString());
            Console.ReadKey();
            Console.Clear();

        }

        private static List<Product> CriarProdutos()
        {
            Product[] productList =
            {
                new Product
                {
                    ProductId = 1,
                    ProductName = "Chai",
                    Category = "Beverages",
                    UnitPrice = 18.0000M,
                    UnitsInStock = 39
                },
                new Product
                {
                    ProductId = 2,
                    ProductName = "Chang",
                    Category = "Beverages",
                    UnitPrice = 19.0000M,
                    UnitsInStock = 17
                },
                new Product
                {
                    ProductId = 3,
                    ProductName = "Aniseed Syrup",
                    Category = "Condiments",
                    UnitPrice = 10.0000M,
                    UnitsInStock = 13
                },
                new Product
                {
                    ProductId = 4,
                    ProductName = "Chef Anton's Cajun Seasoning",
                    Category = "Condiments",
                    UnitPrice = 22.0000M,
                    UnitsInStock = 53
                },
                new Product
                {
                    ProductId = 5,
                    ProductName = "Chef Anton's Gumbo Mix",
                    Category = "Condiments",
                    UnitPrice = 21.3500M,
                    UnitsInStock = 0
                },
                new Product
                {
                    ProductId = 6,
                    ProductName = "Grandma's Boysenberry Spread",
                    Category = "Condiments",
                    UnitPrice = 25.0000M,
                    UnitsInStock = 120
                },
                new Product
                {
                    ProductId = 7,
                    ProductName = "Uncle Bob's Organic Dried Pears",
                    Category = "Produce",
                    UnitPrice = 30.0000M,
                    UnitsInStock = 15
                },
                new Product
                {
                    ProductId = 8,
                    ProductName = "Northwoods Cranberry Sauce",
                    Category = "Condiments",
                    UnitPrice = 40.0000M,
                    UnitsInStock = 6
                },
                new Product
                {
                    ProductId = 9,
                    ProductName = "Mishi Kobe Niku",
                    Category = "Meat/Poultry",
                    UnitPrice = 97.0000M,
                    UnitsInStock = 29
                },
                new Product
                {
                    ProductId = 10,
                    ProductName = "Ikura",
                    Category = "Seafood",
                    UnitPrice = 31.0000M,
                    UnitsInStock = 31
                },
                new Product
                {
                    ProductId = 11,
                    ProductName = "Queso Cabrales",
                    Category = "Dairy Products",
                    UnitPrice = 21.0000M,
                    UnitsInStock = 22
                },
                new Product
                {
                    ProductId = 12,
                    ProductName = "Queso Manchego La Pastora",
                    Category = "Dairy Products",
                    UnitPrice = 38.0000M,
                    UnitsInStock = 86
                },
                new Product
                {
                    ProductId = 13,
                    ProductName = "Konbu",
                    Category = "Seafood",
                    UnitPrice = 6.0000M,
                    UnitsInStock = 24
                },
                new Product
                {
                    ProductId = 14,
                    ProductName = "Tofu",
                    Category = "Produce",
                    UnitPrice = 23.2500M,
                    UnitsInStock = 35
                },
                new Product
                {
                    ProductId = 15,
                    ProductName = "Genen Shouyu",
                    Category = "Condiments",
                    UnitPrice = 15.5000M,
                    UnitsInStock = 39
                },
                new Product
                {
                    ProductId = 16,
                    ProductName = "Pavlova",
                    Category = "Confections",
                    UnitPrice = 17.4500M,
                    UnitsInStock = 29
                },
                new Product
                {
                    ProductId = 17,
                    ProductName = "Alice Mutton",
                    Category = "Meat/Poultry",
                    UnitPrice = 39.0000M,
                    UnitsInStock = 0
                },
                new Product
                {
                    ProductId = 18,
                    ProductName = "Carnarvon Tigers",
                    Category = "Seafood",
                    UnitPrice = 62.5000M,
                    UnitsInStock = 42
                },
                new Product
                {
                    ProductId = 19,
                    ProductName = "Teatime Chocolate Biscuits",
                    Category = "Confections",
                    UnitPrice = 9.2000M,
                    UnitsInStock = 25
                },
                new Product
                {
                    ProductId = 20,
                    ProductName = "Sir Rodney's Marmalade",
                    Category = "Confections",
                    UnitPrice = 81.0000M,
                    UnitsInStock = 40
                },
                new Product
                {
                    ProductId = 21,
                    ProductName = "Sir Rodney's Scones",
                    Category = "Confections",
                    UnitPrice = 10.0000M,
                    UnitsInStock = 3
                },
                new Product
                {
                    ProductId = 22,
                    ProductName = "Gustaf's Knäckebröd",
                    Category = "Grains/Cereals",
                    UnitPrice = 21.0000M,
                    UnitsInStock = 104
                },
                new Product
                {
                    ProductId = 23,
                    ProductName = "Tunnbröd",
                    Category = "Grains/Cereals",
                    UnitPrice = 9.0000M,
                    UnitsInStock = 61
                },
                new Product
                {
                    ProductId = 24,
                    ProductName = "Guaraná Fantástica",
                    Category = "Beverages",
                    UnitPrice = 4.5000M,
                    UnitsInStock = 20
                },
                new Product
                {
                    ProductId = 25,
                    ProductName = "NuNuCa Nuß-Nougat-Creme",
                    Category = "Confections",
                    UnitPrice = 14.0000M,
                    UnitsInStock = 76
                },
                new Product
                {
                    ProductId = 26,
                    ProductName = "Gumbär Gummibärchen",
                    Category = "Confections",
                    UnitPrice = 31.2300M,
                    UnitsInStock = 15
                },
                new Product
                {
                    ProductId = 27,
                    ProductName = "Schoggi Schokolade",
                    Category = "Confections",
                    UnitPrice = 43.9000M,
                    UnitsInStock = 49
                },
                new Product
                {
                    ProductId = 28,
                    ProductName = "Rössle Sauerkraut",
                    Category = "Produce",
                    UnitPrice = 45.6000M,
                    UnitsInStock = 26
                },
                new Product
                {
                    ProductId = 29,
                    ProductName = "Thüringer Rostbratwurst",
                    Category = "Meat/Poultry",
                    UnitPrice = 123.7900M,
                    UnitsInStock = 0
                },
                new Product
                {
                    ProductId = 30,
                    ProductName = "Nord-Ost Matjeshering",
                    Category = "Seafood",
                    UnitPrice = 25.8900M,
                    UnitsInStock = 10
                },
                new Product
                {
                    ProductId = 31,
                    ProductName = "Gorgonzola Telino",
                    Category = "Dairy Products",
                    UnitPrice = 12.5000M,
                    UnitsInStock = 0
                },
                new Product
                {
                    ProductId = 32,
                    ProductName = "Mascarpone Fabioli",
                    Category = "Dairy Products",
                    UnitPrice = 32.0000M,
                    UnitsInStock = 9
                },
                new Product
                {
                    ProductId = 33,
                    ProductName = "Geitost",
                    Category = "Dairy Products",
                    UnitPrice = 2.5000M,
                    UnitsInStock = 112
                },
                new Product
                {
                    ProductId = 34,
                    ProductName = "Sasquatch Ale",
                    Category = "Beverages",
                    UnitPrice = 14.0000M,
                    UnitsInStock = 111
                },
                new Product
                {
                    ProductId = 35,
                    ProductName = "Steeleye Stout",
                    Category = "Beverages",
                    UnitPrice = 18.0000M,
                    UnitsInStock = 20
                },
                new Product
                {
                    ProductId = 36,
                    ProductName = "Inlagd Sill",
                    Category = "Seafood",
                    UnitPrice = 19.0000M,
                    UnitsInStock = 112
                },
                new Product
                {
                    ProductId = 37,
                    ProductName = "Gravad lax",
                    Category = "Seafood",
                    UnitPrice = 26.0000M,
                    UnitsInStock = 11
                },
                new Product
                {
                    ProductId = 38,
                    ProductName = "Côte de Blaye",
                    Category = "Beverages",
                    UnitPrice = 263.5000M,
                    UnitsInStock = 17
                },
                new Product
                {
                    ProductId = 39,
                    ProductName = "Chartreuse verte",
                    Category = "Beverages",
                    UnitPrice = 18.0000M,
                    UnitsInStock = 69
                },
                new Product
                {
                    ProductId = 40,
                    ProductName = "Boston Crab Meat",
                    Category = "Seafood",
                    UnitPrice = 18.4000M,
                    UnitsInStock = 123
                },
                new Product
                {
                    ProductId = 41,
                    ProductName = "Jack's new Product England Clam Chowder",
                    Category = "Seafood",
                    UnitPrice = 9.6500M,
                    UnitsInStock = 85
                },
                new Product
                {
                    ProductId = 42,
                    ProductName = "Singaporean Hokkien Fried Mee",
                    Category = "Grains/Cereals",
                    UnitPrice = 14.0000M,
                    UnitsInStock = 26
                },
                new Product
                {
                    ProductId = 43,
                    ProductName = "Ipoh Coffee",
                    Category = "Beverages",
                    UnitPrice = 46.0000M,
                    UnitsInStock = 17
                },
                new Product
                {
                    ProductId = 44,
                    ProductName = "Gula Malacca",
                    Category = "Condiments",
                    UnitPrice = 19.4500M,
                    UnitsInStock = 27
                },
                new Product
                {
                    ProductId = 45,
                    ProductName = "Rogede sild",
                    Category = "Seafood",
                    UnitPrice = 9.5000M,
                    UnitsInStock = 5
                },
                new Product
                {
                    ProductId = 46,
                    ProductName = "Spegesild",
                    Category = "Seafood",
                    UnitPrice = 12.0000M,
                    UnitsInStock = 95
                },
                new Product
                {
                    ProductId = 47,
                    ProductName = "Zaanse koeken",
                    Category = "Confections",
                    UnitPrice = 9.5000M,
                    UnitsInStock = 36
                },
                new Product
                {
                    ProductId = 48,
                    ProductName = "Chocolade",
                    Category = "Confections",
                    UnitPrice = 12.7500M,
                    UnitsInStock = 15
                },
                new Product
                {
                    ProductId = 49,
                    ProductName = "Maxilaku",
                    Category = "Confections",
                    UnitPrice = 20.0000M,
                    UnitsInStock = 10
                },
                new Product
                {
                    ProductId = 50,
                    ProductName = "Valkoinen suklaa",
                    Category = "Confections",
                    UnitPrice = 16.2500M,
                    UnitsInStock = 65
                },
                new Product
                {
                    ProductId = 51,
                    ProductName = "Manjimup Dried Apples",
                    Category = "Produce",
                    UnitPrice = 53.0000M,
                    UnitsInStock = 20
                },
                new Product
                {
                    ProductId = 52,
                    ProductName = "Filo Mix",
                    Category = "Grains/Cereals",
                    UnitPrice = 7.0000M,
                    UnitsInStock = 38
                },
                new Product
                {
                    ProductId = 53,
                    ProductName = "Perth Pasties",
                    Category = "Meat/Poultry",
                    UnitPrice = 32.8000M,
                    UnitsInStock = 0
                },
                new Product
                {
                    ProductId = 54,
                    ProductName = "Tourtière",
                    Category = "Meat/Poultry",
                    UnitPrice = 7.4500M,
                    UnitsInStock = 21
                },
                new Product
                {
                    ProductId = 55,
                    ProductName = "Pâté chinois",
                    Category = "Meat/Poultry",
                    UnitPrice = 24.0000M,
                    UnitsInStock = 115
                },
                new Product
                {
                    ProductId = 56,
                    ProductName = "Gnocchi di nonna Alice",
                    Category = "Grains/Cereals",
                    UnitPrice = 38.0000M,
                    UnitsInStock = 21
                },
                new Product
                {
                    ProductId = 57,
                    ProductName = "Ravioli Angelo",
                    Category = "Grains/Cereals",
                    UnitPrice = 19.5000M,
                    UnitsInStock = 36
                },
                new Product
                {
                    ProductId = 58,
                    ProductName = "Escargots de Bourgogne",
                    Category = "Seafood",
                    UnitPrice = 13.2500M,
                    UnitsInStock = 62
                },
                new Product
                {
                    ProductId = 59,
                    ProductName = "Raclette Courdavault",
                    Category = "Dairy Products",
                    UnitPrice = 55.0000M,
                    UnitsInStock = 79
                },
                new Product
                {
                    ProductId = 60,
                    ProductName = "Camembert Pierrot",
                    Category = "Dairy Products",
                    UnitPrice = 34.0000M,
                    UnitsInStock = 19
                },
                new Product
                {
                    ProductId = 61,
                    ProductName = "Sirop d'érable",
                    Category = "Condiments",
                    UnitPrice = 28.5000M,
                    UnitsInStock = 113
                },
                new Product
                {
                    ProductId = 62,
                    ProductName = "Tarte au sucre",
                    Category = "Confections",
                    UnitPrice = 49.3000M,
                    UnitsInStock = 17
                },
                new Product
                {
                    ProductId = 63,
                    ProductName = "Vegie-spread",
                    Category = "Condiments",
                    UnitPrice = 43.9000M,
                    UnitsInStock = 24
                },
                new Product
                {
                    ProductId = 64,
                    ProductName = "Wimmers gute Semmelknödel",
                    Category = "Grains/Cereals",
                    UnitPrice = 33.2500M,
                    UnitsInStock = 22
                },
                new Product
                {
                    ProductId = 65,
                    ProductName = "Louisiana Fiery Hot Pepper Sauce",
                    Category = "Condiments",
                    UnitPrice = 21.0500M,
                    UnitsInStock = 76
                },
                new Product
                {
                    ProductId = 66,
                    ProductName = "Louisiana Hot Spiced Okra",
                    Category = "Condiments",
                    UnitPrice = 17.0000M,
                    UnitsInStock = 4
                },
                new Product
                {
                    ProductId = 67,
                    ProductName = "Laughing Lumberjack Lager",
                    Category = "Beverages",
                    UnitPrice = 14.0000M,
                    UnitsInStock = 52
                },
                new Product
                {
                    ProductId = 68,
                    ProductName = "Scottish Longbreads",
                    Category = "Confections",
                    UnitPrice = 12.5000M,
                    UnitsInStock = 6
                },
                new Product
                {
                    ProductId = 69,
                    ProductName = "Gudbrandsdalsost",
                    Category = "Dairy Products",
                    UnitPrice = 36.0000M,
                    UnitsInStock = 26
                },
                new Product
                {
                    ProductId = 70,
                    ProductName = "Outback Lager",
                    Category = "Beverages",
                    UnitPrice = 15.0000M,
                    UnitsInStock = 15
                },
                new Product
                {
                    ProductId = 71,
                    ProductName = "Flotemysost",
                    Category = "Dairy Products",
                    UnitPrice = 21.5000M,
                    UnitsInStock = 26
                },
                new Product
                {
                    ProductId = 72,
                    ProductName = "Mozzarella di Giovanni",
                    Category = "Dairy Products",
                    UnitPrice = 34.8000M,
                    UnitsInStock = 14
                },
                new Product
                {
                    ProductId = 73,
                    ProductName = "Röd Kaviar",
                    Category = "Seafood",
                    UnitPrice = 15.0000M,
                    UnitsInStock = 101
                },
                new Product
                {
                    ProductId = 74,
                    ProductName = "Longlife Tofu",
                    Category = "Produce",
                    UnitPrice = 10.0000M,
                    UnitsInStock = 4
                },
                new Product
                {
                    ProductId = 75,
                    ProductName = "Rhönbräu Klosterbier",
                    Category = "Beverages",
                    UnitPrice = 7.7500M,
                    UnitsInStock = 125
                },
                new Product
                {
                    ProductId = 76,
                    ProductName = "Lakkalikööri",
                    Category = "Beverages",
                    UnitPrice = 18.0000M,
                    UnitsInStock = 57
                },
                new Product
                {
                    ProductId = 77,
                    ProductName = "Original Frankfurter grüne Soße",
                    Category = "Condiments",
                    UnitPrice = 13.0000M,
                    UnitsInStock = 32
                }
            };

            return new List<Product>(productList);
        }
    }
}

